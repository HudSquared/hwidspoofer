# HWID-Kernel-Spoofer

HWID Kernel Spoofer works with kdmapper bytes version for the most recent EAC and BE games (rust, fortnite, apex, dayz, arma, ...) also works on call of duty warzone use it at your own risk !


